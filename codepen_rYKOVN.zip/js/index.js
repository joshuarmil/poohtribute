$(document).ready(function() {
  $("button").addClass("animated bounce")
});