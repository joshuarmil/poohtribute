//$(document).ready(function() {
//  $(".btn").addClass("animated bounce");
//});
$(document).ready(function() {
  $('.type-it').typeIt({
    
  });
});